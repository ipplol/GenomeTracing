﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace SeqinfoCalMutIncidence
{
    class Program
    {
        static void Main(string[] args)
        {
            StreamReader read = new StreamReader(" /SeqInfo.tsv");
            StreamWriter write = new StreamWriter(" /SeqMutation.tsv");
            int i, j, k;
            string line = read.ReadLine();
            line = read.ReadLine();
            while(line!=null)
            {
                string[] line1 = line.Split('\t');
                for(i=0;i<line1.Length;i++)
                {
                    if(line1[i].Contains("Child"))
                    {
                        for (j = i + 1; j < line1.Length; j++)
                            write.WriteLine(line1[j]);
                        break;
                    }
                }
                line = read.ReadLine();
            }
            read.Close();
            write.Close();
        }
    }
}
