﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace CompareSimuResults
{
    public class Sequence
    {
        public string SequenceName;
        public string SeqFather;
        public List<string> SeqAncestors = new List<string>();
        public List<string> SeqChildren = new List<string>();
    }
    class Program
    {
        static List<Sequence> SeqList = new List<Sequence>();
        static void Main(string[] args)
        {
            Random rnd = new Random();
            int i, j, k;
            string fold = " /Simulation";
            //先读入序列关系
            StreamReader read = new StreamReader(fold + "/Ancestors.tsv");
            string line = read.ReadLine();
            SeqList.Add(new Sequence());
            while(line!=null)
            {
                string[] line1 = line.Split('\t');
                string[] line2 = line1[1].Split(' ');
                Sequence newa = new Sequence();
                newa.SequenceName = line1[0];
                for (i = 0; i < line2.Count(); i++)
                {
                    newa.SeqAncestors.Add("SEQ" + line2[i]);
                    SeqList[Convert.ToInt32(line2[i])].SeqChildren.Add(line1[0]);//不看所有的后代
                }
                //SeqList[Convert.ToInt32(line2[i-1])].SeqChildren.Add(line1[0]);//只不看直系子代
                newa.SeqFather = "SEQ" + line2[i - 1];
                SeqList.Add(newa);
                line = read.ReadLine();
            }
            read.Close();

            StreamWriter write = new StreamWriter(fold + "/ResultCompare.tsv");
            write.WriteLine("Generation\tSeq\tMinMutDistance\tUM\tReal_WM\tReal_LD\tInfer_WM\tInfer_LD\tMLTREE");
            //评价结果
            string minimumDistance = "TBD";//最短距离
            int minimumHitNumber = 0;//最短距离的Hit
            int trueHitNumber = 0;//正确的Hit
            for(i=1;i<SeqList.Count;i++)
            {
                string output = Convert.ToString(SeqList[i].SeqAncestors.Count)+ "\t"+ SeqList[i].SequenceName + "\t";
                Console.WriteLine(SeqList[i].SequenceName);

                //-----------------------------------------------UM
                minimumDistance = "TBD";
                minimumHitNumber = 0;
                trueHitNumber = 0;
                read = new StreamReader(fold + "/DesignedMutRate/Results/UM_RealMutRate." + SeqList[i].SequenceName + ".result");
                line = read.ReadLine();
                line = read.ReadLine();
                line = read.ReadLine();
                while (line!=null)
                {
                    string[] line1 = line.Split('\t');
                    if (!SeqList[i].SeqChildren.Contains(line1[2]))//忽略所有子女
                    {
                        if (minimumDistance == "TBD")
                        {
                            minimumDistance = line1[5];
                            minimumHitNumber++;
                            if (SeqList[i].SeqFather == line1[2])
                                trueHitNumber++;
                        }
                        else
                          if (minimumDistance == line1[5])
                        {
                            minimumHitNumber++;
                            if (SeqList[i].SeqFather == line1[2])
                                trueHitNumber++;
                        }
                        else
                            break;
                    }
                    line = read.ReadLine();
                }
                read.Close();
                output += minimumDistance + "\t";
                if (minimumDistance == "0")
                    continue;
                if(trueHitNumber!=0)
                {
                    output += "Correct_";
                    if (minimumHitNumber == 1)
                        output += "Single\t";
                    else
                        output += "Multi\t";
                }
                else
                {
                    output += "Incorrect\t";
                }

                //-------------------------------------Random
                string randompick;
                if (rnd.Next(1, minimumHitNumber + 1) <= trueHitNumber)
                    randompick = "Correct_Single";
                else
                    randompick = "Incorrect";

                //-------------------------------------Real Mutation Rate WM
                minimumDistance = "TBD";
                minimumHitNumber = 0;
                trueHitNumber = 0;
                read = new StreamReader(fold + "/RealMutRate/Results/WM_RealMutRate." + SeqList[i].SequenceName + ".result");
                line = read.ReadLine();
                line = read.ReadLine();
                line = read.ReadLine();
                while (line != null)
                {
                    string[] line1 = line.Split('\t');
                    if (!SeqList[i].SeqChildren.Contains(line1[2]))//忽略所有直系子女
                    {
                        if (minimumDistance == "TBD")
                        {
                            minimumDistance = line1[3];
                            minimumHitNumber++;
                            if (SeqList[i].SeqFather == line1[2])
                                trueHitNumber++;
                        }
                        else
                          if (minimumDistance == line1[3])
                        {
                            minimumHitNumber++;
                            if (SeqList[i].SeqFather == line1[2])
                                trueHitNumber++;
                        }
                        else
                            break;
                    }
                    line = read.ReadLine();
                }
                read.Close();
                if (trueHitNumber != 0)
                {
                    output += "Correct_";
                    if (minimumHitNumber == 1)
                        output += "Single\t";
                    else
                        output += "Multi\t";
                }
                else
                {
                    output += "Incorrect\t";
                }

                //Real Mutation Rate LD
                minimumDistance = "TBD";
                minimumHitNumber = 0;
                trueHitNumber = 0;
                read = new StreamReader(fold + "/RealMutRate/Results/LD_RealMutRate." + SeqList[i].SequenceName + ".result");
                line = read.ReadLine();
                line = read.ReadLine();
                line = read.ReadLine();
                while (line != null)
                {
                    string[] line1 = line.Split('\t');
                    if (!SeqList[i].SeqChildren.Contains(line1[2]))//忽略所有直系子女
                    {
                        if (minimumDistance == "TBD")
                        {
                            minimumDistance = line1[3];
                            minimumHitNumber++;
                            if (SeqList[i].SeqFather == line1[2])
                                trueHitNumber++;
                        }
                        else
                          if (minimumDistance == line1[3])
                        {
                            minimumHitNumber++;
                            if (SeqList[i].SeqFather == line1[2])
                                trueHitNumber++;
                        }
                        else
                            break;
                    }
                    line = read.ReadLine();
                }
                read.Close();
                if (trueHitNumber != 0)
                {
                    output += "Correct_";
                    if (minimumHitNumber == 1)
                        output += "Single\t";
                    else
                        output += "Multi\t";
                }
                else
                {
                    output += "Incorrect\t";
                }

                //--------------------------------[Inferred] Mutation Rate WM
                minimumDistance = "TBD";
                minimumHitNumber = 0;
                trueHitNumber = 0;
                read = new StreamReader(fold + "/InferredRate/Results/WM_RealMutRate." + SeqList[i].SequenceName + ".result");
                line = read.ReadLine();
                line = read.ReadLine();
                line = read.ReadLine();
                while (line != null)
                {
                    string[] line1 = line.Split('\t');
                    if (!SeqList[i].SeqChildren.Contains(line1[2]))//忽略所有直系子女
                    {
                        if (minimumDistance == "TBD")
                        {
                            minimumDistance = line1[3];
                            minimumHitNumber++;
                            if (SeqList[i].SeqFather == line1[2])
                                trueHitNumber++;
                        }
                        else
                          if (minimumDistance == line1[3])
                        {
                            minimumHitNumber++;
                            if (SeqList[i].SeqFather == line1[2])
                                trueHitNumber++;
                        }
                        else
                            break;
                    }
                    line = read.ReadLine();
                }
                read.Close();
                if (trueHitNumber != 0)
                {
                    output += "Correct_";
                    if (minimumHitNumber == 1)
                        output += "Single\t";
                    else
                        output += "Multi\t";
                }
                else
                {
                    output += "Incorrect\t";
                }

                //--------------------------------------[Inferred] Mutation Rate LD
                minimumDistance = "TBD";
                minimumHitNumber = 0;
                trueHitNumber = 0;
                read = new StreamReader(fold + "/InferredRate/Results/LD_RealMutRate." + SeqList[i].SequenceName + ".result");
                line = read.ReadLine();
                line = read.ReadLine();
                line = read.ReadLine();
                while (line != null)
                {
                    string[] line1 = line.Split('\t');
                    if (!SeqList[i].SeqChildren.Contains(line1[2]))//忽略所有直系子女
                    {
                        if (minimumDistance == "TBD")
                        {
                            minimumDistance = line1[3];
                            minimumHitNumber++;
                            if (SeqList[i].SeqFather == line1[2])
                                trueHitNumber++;
                        }
                        else
                          if (minimumDistance == line1[3])
                        {
                            minimumHitNumber++;
                            if (SeqList[i].SeqFather == line1[2])
                                trueHitNumber++;
                        }
                        else
                            break;
                    }
                    line = read.ReadLine();
                }
                read.Close();
                if (trueHitNumber != 0)
                {
                    output += "Correct_";
                    if (minimumHitNumber == 1)
                        output += "Single\t";
                    else
                        output += "Multi\t";
                }
                else
                {
                    output += "Incorrect\t";
                }


                //--------------------------------------TREE
                minimumDistance = "TBD";
                minimumHitNumber = 0;
                trueHitNumber = 0;
                read = new StreamReader(fold + "/TREE/Tree_LineageCombined_1.fa.treefile." + SeqList[i].SequenceName + ".NodeDistance");
                line = read.ReadLine();
                line = read.ReadLine();
                line = read.ReadLine();
                while (line != null)
                {
                    string[] line1 = line.Split('\t');
                    if (!SeqList[i].SeqChildren.Contains(line1[1]))//忽略所有直系子女
                    {
                        if (minimumDistance == "TBD")
                        {
                            minimumDistance = line1[3];
                            minimumHitNumber++;
                            if (SeqList[i].SeqFather == line1[1])
                                trueHitNumber++;
                        }
                        else
                          if (minimumDistance == line1[3])
                        {
                            minimumHitNumber++;
                            if (SeqList[i].SeqFather == line1[1])
                                trueHitNumber++;
                        }
                        else
                            break;
                    }
                    line = read.ReadLine();
                }
                read.Close();
                if (trueHitNumber != 0)
                {
                    output += "Correct_";
                    if (minimumHitNumber == 1)
                        output += "Single\t";
                    else
                        output += "Multi\t";
                }
                else
                {
                    output += "Incorrect\t";
                }

                write.WriteLine(output+randompick);
            }
            write.Close();
        }
    }
}
