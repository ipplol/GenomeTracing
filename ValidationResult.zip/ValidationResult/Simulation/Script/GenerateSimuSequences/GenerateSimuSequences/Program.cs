﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace GenerateSimuSequences
{
    public class Mutation
    {
        public int Position;//突变位置
        public string Reference;//参考碱基
        public string Variation;//突变碱基
        public int MutationRate;//突变率，发生次数，整数
        public List<int> OtherPosInLD = new List<int>();//处于连锁不平衡的其它突变位置
    }
    public class Sequence//生成的序列
    {
        public int SeqID;
        public int Generation;
        public string NucSeq;
        public int ChildNumber = 0;
        public List<int> ChildMut = new List<int>();
        public List<int> Ancestors = new List<int>();
        public List<string> MutationList = new List<string>();
        public List<int> MutationPosList = new List<int>();

        public int MutDistance2Cloest = 9999;
        public int CloestHitNumber = 0;
    }
    class Program
    {
        public static string fold = " ";
        public static int GenerationLimit = 10;//模拟传递多少代 how many generation to simu

        public static string Reference = "+";
        public static List<Mutation> mutationList = new List<Mutation>();//存放所有突变
        public static List<int> mutationRatePool = new List<int>();//存放突变的id，突变率越高，重复次数越多
        public static List<int> childrenNumberPool = new List<int>();//子代数目的分布 a distribution of child number
        public static List<Sequence> seqList = new List<Sequence>();
        public static Random Rnd = new Random();//随机数

        public static Dictionary<int, int> MutationCount = new Dictionary<int, int>();
        static void Readin()//读入参数
        {
            string line;
            int i, j, k;
            //读入突变参数
            mutationRatePool.Add(-1);//加一个占0位，因为random只能返回正整数
            mutationList.Add(new Mutation());
            StreamReader read = new StreamReader(fold + "/Parameter/Para_MutationRate.txt");
            line = read.ReadLine();
            line = read.ReadLine();
            while(line!=null)
            {
                string[] line1 = line.Split('\t');
                Mutation newa = new Mutation();
                newa.Position = Convert.ToInt32(line1[0]);
                newa.Reference = line1[1];
                newa.Variation = line1[2];
                newa.MutationRate = Convert.ToInt32(line1[3]);
                mutationList.Add(newa);
                for (i = 0; i < newa.MutationRate; i++)
                    mutationRatePool.Add(mutationList.Count()-1);
                line = read.ReadLine();
            }
            read.Close();
            //读入LD pair
            read = new StreamReader(fold + "/Parameter/Para_LDPair.txt");
            line = read.ReadLine();
            line = read.ReadLine();
            while (line != null)
            {
                string[] line1 = line.Split('\t');
                List<int> LDa = new List<int>();
                for (i = 1; i < line1.Count(); i++)
                    if (line1[i] != "")
                        LDa.Add(Convert.ToInt32(line1[i]));
                for (i = 1; i < line1.Count(); i++)
                    if (line1[i] != "")
                        mutationList[Convert.ToInt32(line1[i])].OtherPosInLD = LDa;
                line = read.ReadLine();
            }
            read.Close();
            //读入参考基因组
            read = new StreamReader(fold + "/Parameter/Ref_N.fasta");
            line = read.ReadLine();
            line = read.ReadLine();
            Reference += line;
            read.Close();
            //读入子代个数分布
            childrenNumberPool.Add(-1);
            read = new StreamReader(fold + "/Parameter/Para_ChildrenNumberDistribution.txt");
            line = read.ReadLine();
            line = read.ReadLine();
            while (line != null)
            {
                string[] line1 = line.Split('\t');
                for (i = 0; i < Convert.ToInt32(line1[2]); i++)
                    childrenNumberPool.Add(Convert.ToInt32(line1[0]));
                line = read.ReadLine();
            }
            read.Close();
            //初始化SeqList
            Sequence news = new Sequence();
            news.SeqID = 0;
            news.Generation = 0;
            news.NucSeq = Reference;
            seqList.Add(news);
            return;
        }
        static void BuildTree(int[] ans, int newMutIndex)//递归构建模拟树和序列
        {
            //祖先序列的列表，这一代所有的突变
            int i, j, k;
            List<int> ancestors = new List<int>(ans);
            //继承它爹的属性
            Sequence ThisSeq = new Sequence();
            ThisSeq.SeqID = seqList.Count();
            ThisSeq.NucSeq = seqList[ancestors[ancestors.Count() - 1]].NucSeq;
            ThisSeq.Generation = seqList[ancestors[ancestors.Count() - 1]].Generation+1;
            ThisSeq.Ancestors = new List<int>( ancestors);
            ThisSeq.MutationList = new List<string> ( seqList[ancestors[ancestors.Count() - 1]].MutationList);
            ThisSeq.MutationPosList = new List<int>(seqList[ancestors[ancestors.Count() - 1]].MutationPosList);
            //新增从父节点得到的随机突变1个
            int mutindex = newMutIndex;
            if (mutationList[mutindex].OtherPosInLD.Count()==0)//该位置没有连锁
            {
                if (MutationCount.ContainsKey(mutindex))
                    MutationCount[mutindex]++;
                else
                    MutationCount.Add(mutindex, 1);
                //序列
                char[] tmpc = ThisSeq.NucSeq.ToCharArray();
                tmpc[mutindex] = mutationList[mutindex].Variation[0];
                ThisSeq.NucSeq = new string(tmpc);
                //突变list
                ThisSeq.MutationList.Add(Convert.ToString(mutationList[mutindex].Position) + mutationList[mutindex].Reference + "/" + mutationList[mutindex].Variation);
                ThisSeq.MutationPosList.Add(mutationList[mutindex].Position);
            }
            else
            {
                char[] tmpc = ThisSeq.NucSeq.ToCharArray();
                for(i = 0;i < mutationList[mutindex].OtherPosInLD.Count();i++)
                {
                    if (MutationCount.ContainsKey(mutationList[mutindex].OtherPosInLD[i]))
                        MutationCount[mutationList[mutindex].OtherPosInLD[i]]++;
                    else
                        MutationCount.Add(mutationList[mutindex].OtherPosInLD[i], 1);
                    //序列
                    tmpc[mutationList[mutindex].OtherPosInLD[i]] = mutationList[mutationList[mutindex].OtherPosInLD[i]].Variation[0];
                    //突变list
                    ThisSeq.MutationList.Add(Convert.ToString(mutationList[mutindex].OtherPosInLD[i]) + mutationList[mutationList[mutindex].OtherPosInLD[i]].Reference + "/" + mutationList[mutationList[mutindex].OtherPosInLD[i]].Variation);
                    ThisSeq.MutationPosList.Add(mutationList[mutindex].OtherPosInLD[i]);
                }
                ThisSeq.NucSeq = new string(tmpc);
            }

            seqList.Add(ThisSeq);

            //看一下传了多少代了
            if (ThisSeq.Generation >= GenerationLimit)
            {
                return; 
            }
            //产生随机数个子代
            int ChildNumber = childrenNumberPool[Rnd.Next(1, childrenNumberPool.Count())];
            ThisSeq.ChildNumber = ChildNumber;
            ancestors.Add(seqList.Count() - 1);
            for(i=0;i<ChildNumber;i++)
            {
            RandomPick: mutindex = mutationRatePool[Rnd.Next(1, mutationRatePool.Count())];
                //随机得到的该位置尚未突变,给孩子
                if (!ThisSeq.MutationPosList.Contains(mutindex)&&!ThisSeq.ChildMut.Contains(mutindex) && ThisSeq.NucSeq[mutationRatePool[mutindex]] == Reference[mutationRatePool[mutindex]])
                {
                    BuildTree(ancestors.ToArray(), mutindex);
                    ThisSeq.ChildMut.Add(mutindex);
                }
                else
                    goto RandomPick;
            }
            return;
        }
        static void ClosestSearch()//找找最近的，看一下模拟序列的相似度是个什么情况
        {
            int i, j, k;
            for(i=1;i<seqList.Count;i++)
            {
                for(j=1;j<seqList.Count;j++)
                {
                    if (i == j) continue;
                    int sharedMut = 0;
                    for (k = 0; k < seqList[i].MutationList.Count; k++)
                        if (seqList[j].MutationList.Contains(seqList[i].MutationList[k]))
                            sharedMut++;
                    int distance = seqList[i].MutationList.Count + seqList[j].MutationList.Count - sharedMut - sharedMut;
                    if(distance<seqList[i].MutDistance2Cloest)
                    {
                        seqList[i].MutDistance2Cloest = distance;
                        seqList[i].CloestHitNumber = 1;
                    }
                    else
                    if (distance == seqList[i].MutDistance2Cloest)
                    {
                        seqList[i].CloestHitNumber ++;
                    }
                }
            }
        }
        static void WriteTree()//输出
        {
            int i, j, k;
            //输出序列信息
            StreamWriter write = new StreamWriter(fold + "/SeqInfo.tsv");
            for(i=0;i<seqList.Count();i++)
            {
                string output = "";
                for (j = 1; j < seqList[i].Generation; j++)
                    output += "\t";
                output += "["+Convert.ToString(seqList[i].SeqID) + "]\t";
                for (j = 0; j < seqList[i].MutationList.Count(); j++)
                    output += seqList[i].MutationList[j] + " ";
                output += "\tChild:" + Convert.ToString(seqList[i].ChildNumber);
                for (j = 0; j < seqList[i].ChildMut.Count(); j++)
                    output += "\t" + seqList[i].ChildMut[j];
                write.WriteLine(output);
            }
            write.Close();

            //输出序列
            write = new StreamWriter(fold + "/Sequence/SimulatedSeq.tsv");
            for (i = 0; i < seqList.Count(); i++)
            {
                string outid = ">SEQ" + Convert.ToString(seqList[i].SeqID);
                write.Write(outid + "\n");
                write.Write(seqList[i].NucSeq.Substring(1,seqList[i].NucSeq.Length - 1) + "\n");
            }
            write.Close();

            //输出突变发生的次数
            write = new StreamWriter(fold + "/MutationAndCount.tsv");
            foreach( int val in MutationCount.Keys)
            {
                write.Write(val + "\t" + MutationCount[val] + "\n");
            }
            write.Close();

            //输出sample_mutlist
            write = new StreamWriter(fold + "/Simu_mutlist.tsv");
            for (i = 0; i < seqList.Count(); i++)
            {
                string output = "";
                output += "SEQ"+Convert.ToString(seqList[i].SeqID) + "\t";
                for (j = 0; j < seqList[i].MutationList.Count(); j++)
                    output += seqList[i].MutationList[j] + " ";
                write.WriteLine(output.Substring(0,output.Length - 1));
            }
            write.Close();

            //输出序列的Diversity
            write = new StreamWriter(fold + "/Diversity.tsv");
            write.WriteLine("SEQ\tDis2Cloest\tCloestNumber\tChildNumber");
            for (i = 0; i < seqList.Count(); i++)
            {
                string output = "";
                output += "SEQ" + Convert.ToString(seqList[i].SeqID) + "\t";
                output += seqList[i].MutDistance2Cloest + "\t";
                output += seqList[i].CloestHitNumber + "\t";
                output += seqList[i].ChildNumber;
                write.WriteLine(output);
            }
            write.Close();

            //输出序列的祖先节点
            write = new StreamWriter(fold + "/Ancestors.tsv");
            for (i = 1; i < seqList.Count(); i++)
            {
                string output = "";
                output += "SEQ" + Convert.ToString(seqList[i].SeqID) + "\t";
                for (j = 0; j < seqList[i].Ancestors.Count; j++)
                    output += seqList[i].Ancestors[j] + " ";
                write.WriteLine(output.Substring(0,output.Length - 1));
            }
            write.Close();

            return;
        }
        static void Main(string[] args)
        {
            Readin();//读入参数

            List<int> ancestors = new List<int>();
            ancestors.Add(0);
            BuildTree(ancestors.ToArray(), Rnd.Next(1, Reference.Length));//递归构建模拟树和序列
            Console.WriteLine("Sequence Generated: " + Convert.ToString(seqList.Count));
            ClosestSearch();//找找最近的，看一下模拟序列的相似度是个什么情况
            WriteTree();//输出
            return;
        }
    }
}
