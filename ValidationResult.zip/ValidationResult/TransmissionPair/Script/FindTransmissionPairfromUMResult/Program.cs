﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace FindTransmissionPairfromUMResult
{
    public class Metadata
    {
        public  string SeqName = "NA";
        public  string States = "TBD";
        public  double CollectionMonth = 0;
        public string CollectionDate;
    }
    class Program
    {
        static Dictionary<string,Metadata> metadataDic = new Dictionary<string,Metadata>();
        static void Main(string[] args)
        {
            StreamReader read = new StreamReader(" /USABA/USABA_UM_Total/Name.txt");
            Dictionary<string, string> stateName = new Dictionary<string, string>();
            string line = read.ReadLine();
            while (line != null)
            {
                string[] line1 = line.Split('\t');
                stateName.Add(line1[1], line1[0]);
                stateName.Add(line1[0], line1[0]);
                line = read.ReadLine();
            }
            stateName.Add("ABROAD", "ABROAD");
            read.Close();
            int i, j, k;
            read = new StreamReader(" /metadata.tsv");
            line = read.ReadLine();
            line = read.ReadLine();
            while(line!=null)
            {
                line = line.ToUpper();
                string[] line1 = line.Split('\t');
                Metadata a = new Metadata();
                if(!line1[11].Contains("UNITED STATES"))//不是美国序列 Collection Country
                {
                    line1[11] = "UNITED STATES / ABROAD";
                }
                if (!line1[11].Contains("/"))//没有州的信息 State info
                {
                    line = read.ReadLine();
                    continue;
                }
                if (!line1[10].Contains("-"))//没有时间信息 Collection Date info
                {
                    line = read.ReadLine();
                    continue;
                }
                string[] line2 = line1[11].Split('/');
                string states="TBD";
                if (line2.Length == 2)
                    states = line2[1].Substring(1, line2[1].Length - 1);
                if (line2.Length == 3)
                    states = line2[1].Substring(1, line2[1].Length - 2);
                if (stateName.ContainsKey(states))
                    a.States = stateName[states];
                else
                {
                    line = read.ReadLine();
                    continue;
                }
                a.SeqName = line1[1];
                string[] line3 = line1[10].Split('-');
                if (line3.Count() == 2)
                    a.CollectionMonth = Convert.ToDouble(line3[0]) - 2019 + Convert.ToDouble(line3[1]) / 12;
                if (line3.Count() == 3)
                    a.CollectionMonth = Convert.ToDouble(line3[0]) - 2019 + Convert.ToDouble(line3[1]) / 12 + Convert.ToDouble(line3[2])/310; // 2021-06-20 = 2.5.645
                a.CollectionDate = line1[10];
                metadataDic.Add(line1[1], a);
                if(!metadataDic.ContainsKey(line1[3]))
                    metadataDic.Add(line1[3], a);
                line = read.ReadLine();
            }
            read.Close();//readin metadata finished, 所有可以被用的序列meta都在dic中

            //-------read in seq and mutation------------
            Dictionary<string, string> seqMutlist = new Dictionary<string, string>();
            read = new StreamReader("//NAS8500/g/VariationMutation/回复突变/Validation20220331/USABA/GenotypeDetailTotal_noindel_BAtotal.tsv.col");
            line = read.ReadLine();
            while(line!=null)
            {
                string[] lineVz = line.Split('\t');
                if (!seqMutlist.ContainsKey(lineVz[0]))
                    seqMutlist.Add(lineVz[0], line);
                line = read.ReadLine();
            }
            read.Close();

            //-------------------------------------------
            read = new StreamReader(" /USABA/USABA_UM_Total/GenotypeDetailTotal_noindel_BAUSA_Query.tsv");
            StreamWriter write = new StreamWriter(" /USABA/USABA_UM_Total/USAPair.tsv");
            StreamWriter writeQ = new StreamWriter(" /USABA/USABA_UM_Total/USAQuery.tsv");
            StreamWriter writeTreeTsv = new StreamWriter(" /USABA/TreeVGrandTruth/USApairPLP.tsv");
            write.WriteLine("Seq\tStates\tCollectionMonth\tUMTotalHits\tStatesHits\tSNP");
            List<string> TestQuery = new List<string>();
            List<string> OptForTree = new List<string>();//留着扔给进化树看看
            line = read.ReadLine();
            int pairCount = 0;
            while(line!=null)
            {
                string[] line1 = line.Split(':');
                string file = line1[0];
                StreamReader readF = new StreamReader("//NAS8500/g/VariationMutation/回复突变/Validation20220331/USABA/USABA_UM_Total/ResultsTotal/UM_TotalRate." + file + ".result");
                string lineF = readF.ReadLine();
                lineF = readF.ReadLine();
                lineF = readF.ReadLine();
                string minimumDistance = "TBD";
                if(!metadataDic.ContainsKey(file))//Query 不合格
                {
                    line = read.ReadLine();
                    continue;
                }
                List<string> Hits = new List<string>();//可能的hit
                List<string> SecondOpt = new List<string>();//没那么可能的hit
                List<string> IgnoredOpt = new List<string>();//忽略的hit
                k = 0; j = 0;
                
                while(lineF!=null)
                {
                    string[] lineF1 = lineF.Split('\t');
                    if (minimumDistance == "TBD")
                        minimumDistance = lineF1[5];
                    if (Convert.ToInt32(minimumDistance) > 3)//3 snp
                    {
                        lineF = readF.ReadLine();
                        continue;
                    }
                    if (lineF1[5]!=minimumDistance)
                    {
                        break;
                    }
                    if(metadataDic.ContainsKey(lineF1[2]))//开始比较metadata 【时间+州】
                    {
                        if (metadataDic[file].CollectionMonth < metadataDic[lineF1[2]].CollectionMonth)
                        {
                            IgnoredOpt.Add(lineF1[2]);
                        }
                        else
                        {
                            if (Math.Abs(metadataDic[file].CollectionMonth - metadataDic[lineF1[2]].CollectionMonth) < 0.084)//采样时间间隔
                            {
                                if (metadataDic[file].States == metadataDic[lineF1[2]].States)//同一个州采样
                                {
                                    Hits.Add(lineF1[2]);
                                }
                                else//有一个月但不同州的，不能确定传播关系
                                {
                                    Hits.Clear();
                                    break;
                                }
                            }
                            else if (Math.Abs(metadataDic[file].CollectionMonth - metadataDic[lineF1[2]].CollectionMonth) >= 0.166)//采样时间间隔
                            {
                                SecondOpt.Add(lineF1[2]);
                            }
                            else//有在一个月到两个月之间的模糊区域
                            {
                                Hits.Clear();
                                break;
                            }
                        }
                    }
                    /*if (metadataDic.ContainsKey(lineF1[2]))//开始比较metadata 【时间】
                    {
                        if (metadataDic[file].CollectionMonth < metadataDic[lineF1[2]].CollectionMonth)
                        {
                            IgnoredOpt.Add(lineF1[2]);
                        }
                        else
                        {   
                            if (Math.Abs(metadataDic[file].CollectionMonth - metadataDic[lineF1[2]].CollectionMonth) < 0.084)//采样时间间隔
                            {
                                Hits.Add(lineF1[2]);
                            }
                            else if (Math.Abs(metadataDic[file].CollectionMonth - metadataDic[lineF1[2]].CollectionMonth) >= 0.166)//采样时间间隔
                                SecondOpt.Add(lineF1[2]);
                            else//有在一个月到两个月之间的模糊区域
                            {
                                Hits.Clear();
                                break;
                            }
                        }
                        
                    }*/

                    lineF = readF.ReadLine();
                }
                if (Hits.Count() != 0 && SecondOpt.Count() !=0 )
                {
                    pairCount++;
                    Console.WriteLine(file);
                    TestQuery.Add(line);
                    writeQ.Write(line + "\n");
                    write.WriteLine(pairCount+"\t#\t" + file + "\t" + metadataDic[file].States + "\t" + metadataDic[file].CollectionMonth + "\t" + metadataDic[file].CollectionDate + "\t" + SecondOpt.Count() + "\t" + Hits.Count()+"\t"+minimumDistance);
                    for (i = 0; i < Hits.Count; i++)
                    {
                        if (!OptForTree.Contains(seqMutlist[Hits[i]]))
                            OptForTree.Add(seqMutlist[Hits[i]]);
                        write.WriteLine(pairCount + "\t+\t" + Hits[i] + "\t" + metadataDic[Hits[i]].States + "\t" + metadataDic[Hits[i]].CollectionMonth + "\t" + metadataDic[Hits[i]].CollectionDate);
                    }
                    for (i = 0; i < IgnoredOpt.Count; i++)
                        write.WriteLine(pairCount + "\t=\t" + IgnoredOpt[i] + "\t" + metadataDic[IgnoredOpt[i]].States + "\t" + metadataDic[IgnoredOpt[i]].CollectionMonth + "\t" + metadataDic[IgnoredOpt[i]].CollectionDate);
                    for (i = 0; i < SecondOpt.Count; i++)
                    {
                        if (!OptForTree.Contains(seqMutlist[SecondOpt[i]]))
                            OptForTree.Add(seqMutlist[SecondOpt[i]]);
                        write.WriteLine(pairCount + "\t-\t" + SecondOpt[i] + "\t" + metadataDic[SecondOpt[i]].States + "\t" + metadataDic[SecondOpt[i]].CollectionMonth + "\t" + metadataDic[SecondOpt[i]].CollectionDate);
                    }

                    string lineV = line.Replace(":", "\t");
                    lineV = lineV.Replace(",", " ");
                    if (!OptForTree.Contains(lineV))
                        OptForTree.Add(lineV);
                }
                line = read.ReadLine();
            }
            read.Close();
            write.Close();
            writeQ.Close();

            for (i = 0; i < OptForTree.Count(); i++)
                writeTreeTsv.Write(OptForTree[i] + "\n");
            writeTreeTsv.Close();
        }
    }
}
